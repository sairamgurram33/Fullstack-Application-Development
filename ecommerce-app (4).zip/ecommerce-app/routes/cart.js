const express = require("express");
const db = require("../db");
const router = express.Router();
const sendOrderEmail = require("../utils/sendEmail");


// ======================
// ADD TO CART
// ======================
router.post("/add", (req, res) => {

  const user_id = req.session.user.id;
  const { product_id } = req.body;

  db.query(
    "SELECT stock FROM products WHERE id=?",
    [product_id],
    (err, stockResult) => {

      if (stockResult.length === 0) {
        return res.send("Product not found");
      }

      const availableStock = stockResult[0].stock;

      db.query(
        "SELECT quantity FROM cart WHERE user_id=? AND product_id=?",
        [user_id, product_id],
        (err, cartResult) => {

          let currentQty = cartResult.length > 0 ? cartResult[0].quantity : 0;

          if (currentQty >= availableStock) {
            return res.send("Out of Stock");
          }

          if (cartResult.length > 0) {

            db.query(
              "UPDATE cart SET quantity = quantity + 1 WHERE user_id=? AND product_id=?",
              [user_id, product_id],
              () => res.send("Quantity Updated")
            );

          } else {

            db.query(
              "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)",
              [user_id, product_id],
              () => res.send("Added to Cart")
            );

          }

        }
      );

    }
  );

});


// ======================
// GET CART ITEMS
// ======================
router.get("/", (req, res) => {

  if (!req.session.user) {
    return res.status(401).send("Login Required");
  }

  const user_id = req.session.user.id;

  db.query(
    "SELECT p.*, c.quantity, c.product_id FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id=?",
    [user_id],
    (err, results) => {

      if (err) return res.send(err);

      res.json(results);

    }
  );

});


// ======================
// UPDATE QUANTITY (+ / -)
// ======================
router.post("/update", (req, res) => {

  const user_id = req.session.user.id;
  const { product_id, quantity } = req.body;

  if (quantity < 1) {
    return res.send("Invalid quantity");
  }

  db.query(
    "SELECT stock FROM products WHERE id=?",
    [product_id],
    (err, result) => {

      const stock = result[0].stock;

      if (quantity > stock) {
        return res.send("Stock limit reached");
      }

      db.query(
        "UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?",
        [quantity, user_id, product_id],
        (err) => {

          if (err) return res.send(err);

          res.send("Quantity Updated");

        }
      );

    }
  );

});


// ======================
// CHECKOUT
// ======================
router.post("/checkout", (req, res) => {

    const userId = req.session.user.id;

    const query = `
        SELECT p.name, p.price, c.quantity
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = ?
    `;

    db.query(query, [userId], (err, items) => {

        if (err) {
            return res.send("Database Error");
        }

        if (items.length === 0) {
            return res.send("Cart is empty");
        }

        let total = 0;

        items.forEach(item => {
            total += item.price * item.quantity;
        });

        const userEmail = req.session.user.email;
        const userName = req.session.user.name;

        // ✅ 1. SEND RESPONSE FIRST (FAST)
        res.send("Order placed successfully");

        // ✅ 2. SEND EMAIL IN BACKGROUND (NO DELAY)
        sendOrderEmail(userEmail, userName, items, total)
            .then(() => console.log("Email sent"))
            .catch(err => console.log("Email error:", err));

        // ✅ 3. CLEAR CART
        db.query("DELETE FROM cart WHERE user_id = ?", [userId]);

    });
});
// ======================
// REMOVE ITEM FROM CART
// ======================
router.post("/remove", (req, res) => {

  const user_id = req.session.user.id;
  const { product_id } = req.body;

  db.query(
    "DELETE FROM cart WHERE user_id=? AND product_id=?",
    [user_id, product_id],
    (err) => {

      if (err) {
        return res.send("Error removing item");
      }

      res.send("Item removed");

    }
  );

});


module.exports = router;