CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE products (
  id INT PRIMARY KEY,
  name VARCHAR(100),
  price INT,
  image VARCHAR(255)
);

CREATE TABLE cart (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  product_id INT,
  quantity INT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Insert 30 Products

INSERT INTO products VALUES
(1,'Book 1',299,'images/books/book1.jpg'),
(2,'Book 2',399,'images/books/book2.jpg'),
(3,'Book 3',499,'images/books/book3.jpg'),
(4,'Book 4',199,'images/books/book4.jpg'),
(5,'Book 5',599,'images/books/book5.jpg'),
(6,'Laptop 1',45000,'images/laptops/laptop1.jpg'),
(7,'Laptop 2',55000,'images/laptops/laptop2.jpg'),
(8,'Laptop 3',65000,'images/laptops/laptop3.jpg'),
(9,'Laptop 4',70000,'images/laptops/laptop4.jpg'),
(10,'Laptop 5',80000,'images/laptops/laptop5.jpg'),
(11,'Mobile 1',15000,'images/mobiles/mobile1.jpg'),
(12,'Mobile 2',18000,'images/mobiles/mobile2.jpg'),
(13,'Mobile 3',22000,'images/mobiles/mobile3.jpg'),
(14,'Mobile 4',25000,'images/mobiles/mobile4.jpg'),
(15,'Mobile 5',30000,'images/mobiles/mobile5.jpg'),
(16,'Watch 1',2000,'images/watches/watch1.jpg'),
(17,'Watch 2',2500,'images/watches/watch2.jpg'),
(18,'Watch 3',3000,'images/watches/watch3.jpg'),
(19,'Watch 4',3500,'images/watches/watch4.jpg'),
(20,'Watch 5',4000,'images/watches/watch5.jpg'),
(21,'Shoes 1',2500,'images/shoes/shoe1.jpg'),
(22,'Shoes 2',3000,'images/shoes/shoe2.jpg'),
(23,'Shoes 3',3500,'images/shoes/shoe3.jpg'),
(24,'Shoes 4',4000,'images/shoes/shoe4.jpg'),
(25,'Shoes 5',4500,'images/shoes/shoe5.jpg'),
(26,'Book 6',349,'images/books/book6.jpg'),
(27,'Laptop 6',90000,'images/laptops/laptop6.jpg'),
(28,'Mobile 6',32000,'images/mobiles/mobile6.jpg'),
(29,'Watch 6',4500,'images/watches/watch6.jpg'),
(30,'Shoes 6',5000,'images/shoes/shoe6.jpg');