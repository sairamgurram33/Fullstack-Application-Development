const express = require("express");
const db = require("../db");
const router = express.Router();



router.get("/", (req, res) => {
  const user_id = req.session.user.id;

  db.query(
    "SELECT * FROM orders WHERE user_id=? ORDER BY order_date DESC",
    [user_id],
    (err, results) => res.json(results)
  );
});

module.exports = router;