const nodemailer = require("nodemailer");

const sendOrderEmail = async (toEmail, userName, items, total) => {

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: "sairamgurram946@gmail.com",
            pass: "hnifsjaentqprctx"
        }
    });

    let itemList = "";

    items.forEach(item => {
        itemList += `${item.name} (Qty: ${item.quantity}) - ₹${item.price}\n`;
    });

    const mailOptions = {
        from: "ShopKaroo <sairamgurram946@gmail.com>",
        to: toEmail,
        subject: "Order Confirmed - ShopKaroo",
        text: `
Hello ${userName},

Your order has been placed successfully.

Items Purchased:
${itemList}

Total Amount: ₹${total}

Thank you for shopping with ShopKaroo!
`
    };

    await transporter.sendMail(mailOptions);
};

module.exports = sendOrderEmail;