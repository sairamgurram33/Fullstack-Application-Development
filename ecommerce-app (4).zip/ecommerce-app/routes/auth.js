const express = require("express");
const bcrypt = require("bcrypt");
const db = require("../db");
const router = express.Router();


// ================= REGISTER =================
// Register
router.post("/register", async (req, res) => {

  const { name, email, password } = req.body;

  // 🔴 THIS LINE MUST BE PRESENT
  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
    [name, email, hashedPassword],
    (err) => {

      if (err) {
        return res.send("Email already exists");
      }

      res.redirect("/login.html");
    }
  );
});


// ================= LOGIN =================
router.post("/login", (req, res) => {

    const { email, password } = req.body;

    db.query(
        "SELECT * FROM users WHERE email = ?",
        [email],
        async (err, results) => {

            if (err) {
                return res.redirect("/login.html?error=server");
            }

            if (!results || results.length === 0) {
                return res.redirect("/login.html?error=email");
            }

            const user = results[0];

            const match = await bcrypt.compare(password, user.password);

            if (!match) {
                // 🔴 CLEAR ANY SESSION (IMPORTANT)
                req.session.destroy(() => {
                    return res.redirect("/login.html?error=password");
                });
                return;
            }

            // ✅ CREATE NEW SESSION
            req.session.regenerate((err) => {
                if (err) {
                    return res.redirect("/login.html?error=server");
                }

                req.session.user = {
                    id: user.id,
                    name: user.name,
                    email: user.email
                };

                res.redirect("/index.html");
            });
        }
    );
});

// ================= SESSION CHECK =================
router.get("/session", (req, res) => {
    if (req.session.user) {
        res.json({ loggedIn: true, user: req.session.user });
    } else {
        res.json({ loggedIn: false });
    }
});


// ================= LOGOUT =================
router.get("/logout", (req, res) => {
    req.session.destroy(() => {
        res.redirect("/login.html");
    });
});


module.exports = router;