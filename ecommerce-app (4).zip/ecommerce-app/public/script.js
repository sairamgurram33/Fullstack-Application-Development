let currentUser = null;
let allProducts = [];

window.onload = async function () {

    const session = await fetch("/auth/session").then(res => res.json());

    if (!session.loggedIn) {
        window.location.href = "login.html";
        return;
    }

    currentUser = session.user;

    loadProducts();
    loadCart();
};


// LOAD PRODUCTS
function loadProducts(){

    fetch("/products")
    .then(res => res.json())
    .then(data => {

        allProducts = data;
        displayProducts(data);

    });

}


// DISPLAY PRODUCTS
function displayProducts(products){

    const container = document.getElementById("products");
    container.innerHTML = "";

    products.forEach(product => {

        container.innerHTML += `
        <div class="card">

            <img src="${product.image}">

            <h3>${product.name}</h3>

            <p>₹ ${product.price}</p>

            <p>Stock: ${product.stock}</p>

            <button class="btn"
                onclick="addToCart(${product.id})"
                ${product.stock <= 0 ? "disabled" : ""}>

                ${product.stock <= 0 ? "Out of Stock" : "Add to Cart"}

            </button>

        </div>
        `;

    });

}


// ADD TO CART
function addToCart(product_id){

    fetch("/cart/add",{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body: JSON.stringify({product_id})
    })
    .then(res => res.text())
    .then(()=>{
        loadCart();
        loadProducts();
    });

}


// LOAD CART
function loadCart(){

    fetch("/cart")
    .then(res => res.json())
    .then(data => {

        const cart = document.getElementById("cart");
        const badge = document.getElementById("cart-count");

        cart.innerHTML = "";

        if(data.length === 0){

            cart.innerHTML = "<p>Your cart is empty</p>";
            badge.innerText = 0;
            return;

        }

        let total = 0;
        let count = 0;

        data.forEach(item => {

            total += item.price * item.quantity;
            count += item.quantity;
cart.innerHTML += `
<div class="cart-item">

    <img src="${item.image}" width="60">

    <div>

        <h4>${item.name}</h4>

        <p>₹ ${item.price}</p>

        <div class="qty">

            <button onclick="updateQty(${item.product_id}, ${item.quantity - 1})">-</button>

            <span>${item.quantity}</span>

            <button onclick="updateQty(${item.product_id}, ${item.quantity + 1})">+</button>

        </div>

        <button onclick="removeItem(${item.product_id})" style="margin-top:5px;background:red;color:white;border:none;padding:4px 8px;border-radius:4px;cursor:pointer;">
            Remove
        </button>

    </div>

</div>
`;

        });

        badge.innerText = count;

        cart.innerHTML += `<hr><h3>Total: ₹ ${total}</h3>`;

    });

}


// UPDATE QUANTITY
function updateQty(product_id, quantity){

    if(quantity < 1) return;

    fetch("/cart/update",{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body: JSON.stringify({product_id, quantity})
    })
    .then(res => res.text())
    .then(()=>{
        loadCart();
        loadProducts();
    });

}
// ======================
// REMOVE ITEM
// ======================
function removeItem(product_id){

    fetch("/cart/remove",{
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body: JSON.stringify({product_id})
    })
    .then(res => res.text())
    .then(()=>{
        loadCart();
        loadProducts();
    });

}


// CHECKOUT
function checkout(){

    fetch("/cart/checkout",{method:"POST"})
    .then(()=>{
        document.getElementById("popup").style.display = "flex";
        loadCart();
        loadProducts();
    });

}


// LOGOUT
function logout(){
    window.location.href="/auth/logout";
}


// TOGGLE CART
function toggleCart(){

    const sidebar = document.getElementById("cart-sidebar");
    const overlay = document.getElementById("overlay");

    sidebar.classList.toggle("active");

    overlay.style.display =
        sidebar.classList.contains("active") ? "block" : "none";

}


// CLOSE POPUP
function closePopup(){
    document.getElementById("popup").style.display="none";
}