console.log("E-Commerce App Loaded Successfully!");
