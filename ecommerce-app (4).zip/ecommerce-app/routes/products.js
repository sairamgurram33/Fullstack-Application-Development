const express = require("express");
const db = require("../db");
const router = express.Router();


router.get("/", (req, res) => {
  if (!req.session.user) {
    return res.status(401).send("Login Required");
  }

  db.query("SELECT * FROM products", (err, results) => {
    res.json(results);
  });
});

module.exports = router;